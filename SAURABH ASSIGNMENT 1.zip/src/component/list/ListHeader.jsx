const ListHeader = ({ children }) => {
  return <tr>{children}</tr>;
};

export default ListHeader;
